from django.db import models
from .Airport import Airport
from .Flight import Flight

class Passenger(models.Model):
	FirstName = models.CharField(max_length=30)
	LastName = models.CharField(max_length=30)
	flights = models.ManyToManyField(Flight, blank=True, related_name="passenger")
	
	def __str__(self):
		return f"{self.FirstName} {self.LastName}"