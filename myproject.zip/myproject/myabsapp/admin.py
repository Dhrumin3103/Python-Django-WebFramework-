from django.contrib import admin
from .models import Product, Book, EBook, Cart 

# Register your models here.
admin.site.register(Product)
admin.site.register(Book)
admin.site.register(EBook)
admin.site.register(Cart)
