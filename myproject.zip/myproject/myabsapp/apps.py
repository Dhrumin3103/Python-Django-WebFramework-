from django.apps import AppConfig


class MyabsappConfig(AppConfig):
    name = 'myabsapp'
