from django.contrib.auth import get_user_model
from django.db import models

#Concept of Concrete Base Model

class Product(models.Model):
    name = models.CharField(max_length=100)
    price = models.PositiveIntegerField(help_text='in ₹')

    def __str__(self) -> str:
        return self.name


class Book(Product):
    weight = models.PositiveIntegerField()


class EBook(Product):
    download_link = models.URLField()

class Cart(models.Model):
    user = models.OneToOneField(get_user_model(), primary_key=True, on_delete=models.CASCADE)
    items = models.ManyToManyField(Product)