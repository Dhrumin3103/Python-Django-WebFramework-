from django import forms
from .models import RegisterData


class RegistrationForm(forms.Form):
	username = forms.CharField(max_length=25)
	password = forms.CharField(max_length=25)
	#email = forms.CharField(max_length=30)
	phone = forms.CharField(max_length=10)
	email= forms.EmailField()
    #phone= forms.IntegerField(max_length=10)
	
class RegistrationModelForm(forms.ModelForm):
	class Meta:
		model = RegisterData

		fields = [
			'username',
			'password',
			'email',
			'phone'
		]

		widgets = {

			'username':forms.TextInput(attrs={'class':'form-control','placeholder':'Username'}),
			'password':forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}),
			'email':forms.EmailInput(attrs={'class':'form-control','placeholder':'Email_Id'}),
			'phone':forms.NumberInput(attrs={'class':'form-control','placeholder':'Phone Number'}),


		}