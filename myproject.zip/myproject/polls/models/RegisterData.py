from django.db import models

class RegisterData(models.Model):
	username = models.CharField(max_length=25)
	password = models.CharField(max_length=25)
	#email = models.CharField(max_length=30)
	email= models.EmailField()
	phone = models.CharField(max_length=10)
	#phone= models.IntegerField(max_length=10)


	def __str__(self):
		return self.username