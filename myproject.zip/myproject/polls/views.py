from django.shortcuts import render, redirect
from django.shortcuts import HttpResponse
from .models import News 
from .forms import RegistrationForm, RegistrationModelForm
from .models import RegisterData
from django.contrib import messages
# Create your views here.
def home(request):
	context = { "text" : "This is from home",
				"mynumber" :380007,
				"mylist" : ["Dhrumin","Chirag","Mayur"]



			  }
	return render(request,"home.html",context)

def contact(request):
	context = { "text" : "This is from contact",
				"mynumber" : 3800017,
				"mycontlist":["DMN","Nupur","papa"]


	}
	return render(request,"contact.html",context)

def about(request):
	context = { "text" : "THis is from about",
				"mynumber" : 9408759201


	}
	return render(request,"about.html",context)


def news_details(request):
	obj = News.objects.get(id=2)
	context = { 
		"object":obj
	}
	return render(request,"news_details.html",context)


def news_year(request, year):
	a_list = News.objects.filter(pub_date__year = year)
	context = { 
		'year':year,
		'article_list':a_list
	}
	return render(request,"news_year.html",context)

def register(request):
	context = {"form":RegistrationForm}
	return render(request,"registration.html",context)


def addUser(request):
	form = RegistrationForm(request.POST)

	if form.is_valid():
		register = RegisterData(username = form.cleaned_data['username'],
								password = form.cleaned_data['password'],
								email = form.cleaned_data['email'],
								phone = form.cleaned_data['phone'])

		register.save()
		messages.add_message(request,messages.SUCCESS,"You have Register successfully")

	return redirect('add')


def modelformview(request):
	context = { 
		'modelform':RegistrationModelForm
	 }
	return render(request,"modelform.html",context)

def addModelForm(request):
	mymodelform = RegistrationModelForm(request.POST)

	if mymodelform.is_valid():
		mymodelform.save()

	return redirect('addmodelform')